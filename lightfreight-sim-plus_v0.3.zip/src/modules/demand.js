export class Demand{
  attach(e){ this.e=e; }
  pre(S,log){
    const scs={
      city:{ drops:30, area:[0,0,12,10], tw:[9,21], redeliv_base:0.10, rain_p:0.25, base_price:520, cold_share:0.1 },
      suburb:{ drops:24, area:[0,0,20,16], tw:[9,20], redeliv_base:0.08, rain_p:0.20, base_price:620, cold_share:0.08 },
      cold:{ drops:18, area:[0,0,20,16], tw:[9,20], redeliv_base:0.06, rain_p:0.20, base_price:700, cold_share:0.35 }
    };
    S._scenario = scs[S.scenario]||scs.city;
    const sc=S._scenario, [x0,y0,w,h]=sc.area;
    const jobs=[];
    for(let i=0;i<sc.drops;i++){
      const cold=Math.random()<sc.cold_share;
      const x=x0+Math.random()*w, y=y0+Math.random()*h;
      const tws=sc.tw[0]+Math.floor(Math.random()*4);
      const twe=Math.max(tws+2, sc.tw[0]+1);
      jobs.push({ id:'J'+(i+1), x, y, cold, tw:[tws,Math.min(twe,sc.tw[1])],
        price: sc.base_price + (cold?S.params.cold_surcharge:0),
        redeliv_r: sc.redeliv_base + (cold?0.02:0),
        svc_min: Math.random()<0.2?8:5, late:false });
    }
    S.jobs = jobs;
    log(`📦 案件生成: ${jobs.length}件`);
  }
}