export class Ops{
  attach(e){ this.e=e; }
  post(S,log){
    const rain = Math.random()< (S._scenario?.rain_p||0.2);
    // 出勤判定（簡易）
    const presentDrivers = S.drivers.filter(d => Math.random() < d.availability);
    const maxVehicles = Math.min(presentDrivers.length, S.fleet.length);
    if(maxVehicles < S.fleet.length){
      log(`👥 欠勤 ${S.fleet.length - maxVehicles} 名 → 同数の車両は未稼働`);
    }
    const activeRoutes = S.routes.slice(0, maxVehicles);
    let totalKm=0, ontime=0, total=0, redeliv=0, latePenalty=0, damagePenalty=0, fuelCost=0, laborCost=0, deadKm=0, co2=0, fleetCost=0;
    const lateJobs = new Set();

    for(const idx in activeRoutes){
      const r = activeRoutes[idx];
      if(!r.seq.length) continue;
      const v = r.v;
      // 固定費
      fleetCost += (v.lease_per_day||0) + (v.insurance_per_day||0);

      let t=9, pos={...S.params.depot}, kmSum=0, loaded=r.seq.length;
      let driveH=0, handleH=0;

      for(const j of r.seq){
        const km=Math.hypot(pos.x-j.x,pos.y-j.y);
        const speedAdj = v.speed_kmph * (rain?0.9:1.0) * (1 - 0.03*Math.min(loaded,10));
        const travel = km/Math.max(8,speedAdj);
        t += travel; driveH+=travel; kmSum+=km;
        if(t<j.tw[0]) t=j.tw[0];
        const nd_p = j.redeliv_r * (t<12?1.1:0.9) * (rain?1.05:1.0);
        const notHome = Math.random()<nd_p;
        if(notHome){ redeliv++; t += S.params.redeliv_back_time; }
        const svc=j.svc_min/60 * (notHome?0.3:1.0);
        t+=svc; handleH+=svc;

        const isLate = t>j.tw[1];
        if(isLate){ latePenalty += S.params.late_penalty; lateJobs.add(j.id); }
        else ontime++;

        if(Math.random() < (0.01 + (rain?0.003:0))){ damagePenalty += S.params.damage_penalty; }
        pos=j; loaded--; total++;
      }
      kmSum += r.back_km; driveH += r.back_h; deadKm += r.back_km;
      totalKm += kmSum;

      // 変動費：燃料/電費 + メンテ
      const isEV = v.type==='ev';
      fuelCost += isEV ? (kmSum*0.18*S.params.ev_kwh_price) : (kmSum*S.params.fuel_price/15);
      co2 += isEV ? (kmSum*S.params.co2_ev_per_km) : (kmSum*S.params.co2_gas_per_km);
      fleetCost += (v.maint_per_km||0) * kmSum;

      // 労務：残業ペナルティ
      const hours = driveH + handleH;
      laborCost += hours * v.wage_per_hour;
      if(hours>S.params.max_hours_per_driver){ latePenalty += Math.max(0,hours-S.params.max_hours_per_driver)*500; }
    }
    const ontimeRate = total? ontime/total : 1;
    const redelivRate = total? redeliv/total : 0;
    S.ops = { rain, lateJobs: Array.from(lateJobs), totalKm, ontimeRate, redelivRate, latePenalty, damagePenalty, fuelCost, laborCost, deadhead: totalKm? deadKm/totalKm:0, co2, fleetCost };
  }
}