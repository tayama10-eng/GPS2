const dist=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
const travelTime=(km, v)=>km/Math.max(8,v);
function routeCost(r, seq, W){
  let pos={...W}, t=9, kmSum=0, late=0;
  for(const j of seq){
    const km=dist(pos,j); t+=travelTime(km,r.v.speed_kmph); kmSum+=km;
    if(t<j.tw[0]) t=j.tw[0];
    const lateH=Math.max(0, t - j.tw[1]); late += lateH;
    t+=j.svc_min/60; pos=j;
  }
  const back=dist(pos,W); kmSum+=back; t+=travelTime(back,r.v.speed_kmph);
  // 遅延の重みを強化（時間窓厳密度UP）
  return kmSum + 8*late;
}
export class Dispatch{
  attach(e){ this.e=e; }
  step(S,log){
    const W=S.params.depot;
    const fleet = S.fleet.map(v=>({v, seq:[], km:0, back_km:0, back_h:0}));
    const state=new Map(S.fleet.map(v=>[v.id,{pos:{...W}, time:9, cap:0}]));
    const unassigned=[...S.jobs].sort((a,b)=>a.tw[1]-b.tw[1]);
    while(unassigned.length){
      const j=unassigned.shift();
      let best=null;
      for(const r of fleet){
        const st=state.get(r.v.id);
        if(st.cap>=r.v.cap_drops) continue;
        const km=dist(st.pos,j); const arr=st.time+travelTime(km,r.v.speed_kmph);
        const wait=Math.max(0,j.tw[0]-arr); const svc=j.svc_min/60; const leave=arr+wait+svc;
        if(leave<=j.tw[1]+0.5){
          const score=(j.tw[1]-leave) + (1/(1+km));
          if(!best || score>best.score) best={r,st,j,km,leave};
        }
      }
      if(best){
        best.r.seq.push(j); best.r.km+=best.km;
        best.st.pos={x:j.x,y:j.y}; best.st.time=best.leave; best.st.cap++;
      } else {
        // どこにも乗らない→最小timeの車へ（遅延覚悟）
        fleet.sort((a,b)=>state.get(a.v.id).time - state.get(b.v.id).time);
        const r=fleet[0], st=state.get(r.v.id), km=dist(st.pos,j);
        r.seq.push(j); r.km+=km; st.pos={x:j.x,y:j.y};
        st.time+=travelTime(km,r.v.speed_kmph)+j.svc_min/60; st.cap++;
      }
    }
    // 2-opt 改善
    for(const r of fleet){
      let best=r.seq, L=best.length, improved=true, base=routeCost(r,best,W);
      while(improved){
        improved=false;
        for(let i=1;i<L-2;i++){
          for(let k=i+1;k<L-1;k++){
            const cand=best.slice(0,i).concat(best.slice(i,k).reverse(),best.slice(k));
            const c=routeCost(r,cand,W);
            if(c+0.001<base){ best=cand; base=c; improved=true; }
          }
        }
      }
      r.seq=best;
    }
    // Relocate（1点挿入）
    for(const r of fleet){
      let changed=true;
      while(changed){
        changed=false;
        for(let i=0;i<r.seq.length;i++){
          const j=r.seq[i];
          for(let pos=0; pos<r.seq.length; pos++){
            if(pos===i) continue;
            const cand = r.seq.slice(); cand.splice(i,1); cand.splice(pos,0,j);
            const c0 = routeCost(r,r.seq,W), c1=routeCost(r,cand,W);
            if(c1+0.001 < c0){ r.seq=cand; changed=true; break; }
          }
          if(changed) break;
        }
      }
    }
    // 戻り
    for(const r of fleet){
      if(r.seq.length){
        const last=r.seq[r.seq.length-1];
        r.back_km = dist(last,W);
        r.back_h  = travelTime(r.back_km, r.v.speed_kmph);
      }
    }
    S.routes = fleet;
    log(`🧭 配車完了: 2-opt+Relocate 適用`);
  }
}