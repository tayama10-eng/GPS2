# LightFreight Sim PLUS (Non-Commercial) — v0.3

**追加機能（あなたの要望 3点）**
1. **地図UI（Canvas）**：デポとジョブ位置・ルートを可視化（タイルなしの座標マップ）。
2. **VRP高度化**：Greedy→2-opt→**Relocate**（局所改善）＋**時間窓厳密度UP**（遅延ペナルティ強化＆可視化）。
3. **財務/人事**：車両**リース/保険/整備**、走行kmに応じた**メンテ**、**シフト（出勤/欠勤/早退/残業）**を導入。

- 純フロントエンド（PWA）／No build。GitHub Pagesにそのままデプロイ。
- KPI：On-time / 再配達 / drops per km / deadhead% / CO₂e/km / 利益 に加え、**Lease/Maint/Insurance**も反映。

## 使い方
1) `index.html` を開く（またはPagesにデプロイ）
2) 右上メニューから **シナリオ**選択 → **1日運行 / 1週間**。
3) 「地図」タブでルート可視化を確認。

## GitHubに“一発”で送る（アップロードが面倒な人向け）
```bash
# 事前: GitHub CLI をインストール & gh auth login 済み
unzip lightfreight-sim-plus_v0.3.zip -d lightfreight-sim-plus
cd lightfreight-sim-plus
git init
git add .
git commit -m "LightFreight Sim PLUS v0.3"
gh repo create <your-name>/lightfreight-sim-plus --public --source . --remote origin --push
# Pages 有効化（Settings→Pages）またはデフォルトWorkflowで自動公開
```

_生成: 2025-10-11T14:53:00.571520Z_
