export class Finance{
  attach(e){ this.e=e; }
  post(S,log){
    const rev = S.jobs.reduce((a,j)=>a+j.price,0);
    S.ar += rev;
    const o=S.ops||{fuelCost:0,laborCost:0,latePenalty:0,damagePenalty:0,totalKm:0,ontimeRate:1,redelivRate:0,deadhead:0,co2:0,fleetCost:0};
    const cost = o.fuelCost + o.laborCost + o.latePenalty + o.damagePenalty + o.fleetCost;
    const profit = rev - cost;
    Object.assign(S.kpi, {
      fuel:o.fuelCost, labor:o.laborCost, fleetCost:o.fleetCost, penalty:o.latePenalty+o.damagePenalty, profit,
      ontime:o.ontimeRate, redeliv:o.redelivRate,
      density: o.totalKm? (S.jobs.length/o.totalKm):0,
      deadhead:o.deadhead, co2: o.totalKm? (o.co2/o.totalKm):0
    });
    if(S.day % S.params.invoice_lag_days === 0){ S.cash += S.ar; S.ar = 0; this.e.log(`💰 売掛入金（サイト${S.params.invoice_lag_days}日）`); }
    // 遅延ジョブ可視ログ
    if((S.ops?.lateJobs||[]).length){ this.e.log(`⏰ 遅延: ${S.ops.lateJobs.join(', ')}`); }
  }
}