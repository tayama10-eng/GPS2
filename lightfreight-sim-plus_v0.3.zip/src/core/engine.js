export class Engine{
  constructor(){
    this.S = {
      day:1, cash: 1500000, ar:0, scenario:'city',
      kpi:{ fuel:0, labor:0, fleetCost:0, penalty:0, profit:0, ontime:1, redeliv:0, density:0, deadhead:0, co2:0 },
      fleet:[
        { id:'V1', type:'van', cap_drops:40, speed_kmph:22, cost_per_km:30, wage_per_hour:1400,
          lease_per_day:2500, insurance_per_day:600, maint_per_km:7 },
        { id:'V2', type:'van', cap_drops:40, speed_kmph:22, cost_per_km:30, wage_per_hour:1400,
          lease_per_day:2500, insurance_per_day:600, maint_per_km:7 },
        { id:'R1', type:'reefer', cap_drops:28, speed_kmph:20, cost_per_km:36, wage_per_hour:1500,
          lease_per_day:3200, insurance_per_day:700, maint_per_km:9 },
        { id:'E1', type:'ev', cap_drops:32, speed_kmph:24, cost_per_km:18, wage_per_hour:1450,
          lease_per_day:3000, insurance_per_day:650, maint_per_km:6 }
      ],
      drivers:[
        { id:'D1', exp:0.7, safety:0.8, availability:0.95 },
        { id:'D2', exp:0.6, safety:0.7, availability:0.92 },
        { id:'D3', exp:0.8, safety:0.8, availability:0.90 },
        { id:'D4', exp:0.7, safety:0.75, availability:0.93 }
      ],
      params:{
        fuel_price:180, ev_kwh_price:28, co2_gas_per_km:180, co2_ev_per_km:60,
        late_penalty:800, damage_penalty:1500, cold_surcharge:120,
        invoice_lag_days:14, max_hours_per_driver:9, redeliv_back_time:0.4,
        depot:{x:0,y:0}
      },
      log:[], routes:[], jobs:[], ops:{},
    };
    this.modules=[];
    this.log=(m)=>{ this.S.log.unshift(m); if(this.S.log.length>500)this.S.log.pop(); };
  }
  register(m){ m.attach?.(this); this.modules.push(m); }
  stepDay(){
    this.modules.forEach(m=>m.pre?.(this.S,this.log));
    this.modules.forEach(m=>m.step?.(this.S,this.log));
    this.modules.forEach(m=>m.post?.(this.S,this.log));
    this.S.day += 1;
  }
}