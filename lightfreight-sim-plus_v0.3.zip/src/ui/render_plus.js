const $ = (id)=>document.getElementById(id);
const fmtJPY=(n)=>'¥'+Math.round(n).toLocaleString();

export function initUI(engine, onAfterRender){
  const sel=$('scenarioSel');
  sel.innerHTML = `<option value="city">都市・短距離</option><option value="suburb">郊外・中距離</option><option value="cold">コールドチェーン多め</option>`;
  sel.value = engine.S.scenario;
  sel.onchange=()=>{ engine.S.scenario = sel.value; };

  $('runDay').onclick=()=>{ runDay(engine, onAfterRender); };
  $('runWeek').onclick=()=>{ for(let i=0;i<7;i++) runDay(engine, onAfterRender); };
  $('save').onclick=()=>{ localStorage.setItem('lf_sim_save', JSON.stringify(engine.S)); engine.log('💾 保存'); renderAll(engine); onAfterRender?.(); };
  $('load').onclick=()=>{ const raw=localStorage.getItem('lf_sim_save'); if(raw){ engine.S = JSON.parse(raw); engine.log('📂 読込'); renderAll(engine); onAfterRender?.(); } };
  $('reset').onclick=()=>{ const keep = engine.S.scenario; const E = engine.constructor; const e = new E(); Object.assign(engine, e); engine.S.scenario=keep; engine.log('🗑 新規'); renderAll(engine); onAfterRender?.(); };

  // Tabs
  bindTabs(()=>onAfterRender?.());
  renderAll(engine);
}
function runDay(engine, onAfterRender){
  try{ engine.S.fleet = JSON.parse(document.getElementById('fleetBox').textContent); }catch{}
  engine.stepDay();
  renderAll(engine);
  onAfterRender?.();
}
export function renderAll(engine){
  const S=engine.S, by=(id,v)=>document.getElementById(id).textContent=v;
  by("day", `Day ${S.day}`);
  by("cash", fmtJPY(S.cash));
  by("ar", fmtJPY(S.ar));
  by("fuel", fmtJPY(S.kpi.fuel));
  by("labor", fmtJPY(S.kpi.labor));
  by("fleetCost", fmtJPY(S.kpi.fleetCost));
  by("pen", fmtJPY(S.kpi.penalty));
  by("profit", fmtJPY(S.kpi.profit));
  by("ontime", `${(S.kpi.ontime*100).toFixed(1)}%`);
  by("redeliv", `${(S.kpi.redeliv*100).toFixed(1)}%`);
  by("density", `${S.kpi.density.toFixed(2)}`);
  by("deadhead", `${(S.kpi.deadhead*100).toFixed(1)}%`);
  by("co2", `${S.kpi.co2.toFixed(0)} g-CO₂/km`);
  document.getElementById("log").textContent = S.log.slice(0,120).map(x=>'• '+x).join('\n');
  document.getElementById("routes").textContent = (S.routes||[]).map(r=>`${r.v.id}(${r.v.type}) drops:${r.seq.length} km:${(r.km+(r.back_km||0)).toFixed(1)}`).join('\n');
  document.getElementById("fleetBox").textContent = JSON.stringify(S.fleet,null,2);
  document.getElementById("paramBox").textContent = JSON.stringify({scenario:S.scenario, ...S.params}, null, 2);
}
export function bindTabs(cb){
  const tabs = document.querySelectorAll('#tabs .tab');
  tabs.forEach(t=>t.onclick=()=>{
    tabs.forEach(x=>x.classList.remove('on')); t.classList.add('on');
    const id = t.dataset.tab;
    document.querySelectorAll('.panel').forEach(p=>p.classList.remove('on'));
    document.getElementById('panel-'+id).classList.add('on');
    cb?.(id);
  });
}
