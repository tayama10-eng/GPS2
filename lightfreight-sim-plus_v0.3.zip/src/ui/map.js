export function drawMap(engine){
  const canvas = document.getElementById('map');
  if(!canvas) return;
  const ctx = canvas.getContext('2d');
  const S=engine.S, W=S.params.depot;
  const jobs=S.jobs||[], routes=S.routes||[];
  // compute bounds
  let minx=0, miny=0, maxx=1, maxy=1;
  for(const j of jobs){ minx=Math.min(minx,j.x); miny=Math.min(miny,j.y); maxx=Math.max(maxx,j.x); maxy=Math.max(maxy,j.y); }
  const pad=1; minx-=pad; miny-=pad; maxx+=pad; maxy+=pad;
  const w=canvas.width, h=canvas.height;
  const sx = w/(maxx-minx||1), sy=h/(maxy-miny||1);
  const toC = (p)=>({ x:(p.x-minx)*sx, y:(maxy-p.y)*sy });

  ctx.clearRect(0,0,w,h);
  // grid
  ctx.globalAlpha=0.2; ctx.beginPath();
  for(let gx=Math.ceil(minx); gx<=Math.floor(maxx); gx++){ const X=(gx-minx)*sx; ctx.moveTo(X,0); ctx.lineTo(X,h); }
  for(let gy=Math.ceil(miny); gy<=Math.floor(maxy); gy++){ const Y=(maxy-gy)*sy; ctx.moveTo(0,Y); ctx.lineTo(w,Y); }
  ctx.strokeStyle="#3a475a"; ctx.stroke(); ctx.globalAlpha=1;

  // depot
  const d = toC(W);
  ctx.fillStyle="#fff"; ctx.fillRect(d.x-4,d.y-4,8,8);

  // routes
  for(const r of routes){
    if(!r.seq.length) continue;
    ctx.beginPath();
    const start = toC(W);
    ctx.moveTo(start.x,start.y);
    for(const j of r.seq){ const p=toC(j); ctx.lineTo(p.x,p.y); }
    const end = toC(r.seq[r.seq.length-1]);
    ctx.lineTo(start.x,start.y);
    ctx.strokeStyle = "#88b"; ctx.lineWidth=1.5; ctx.stroke();
  }

  // jobs
  for(const j of jobs){
    const p=toC(j);
    const late = (S.ops?.lateJobs||[]).includes(j.id);
    ctx.beginPath();
    ctx.arc(p.x,p.y, late?4:3, 0, Math.PI*2);
    ctx.fillStyle = late? "#e55":"#8fd";
    ctx.fill();
  }
}